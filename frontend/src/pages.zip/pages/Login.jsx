import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', senha: '' });
  const [erro, setErro] = useState('');

  useEffect(() => {
    const logado = localStorage.getItem('logado');
    if (logado) navigate('/');
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
    setErro('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Acesso xumbado
    if (form.email === 'admin@teste.com' && form.senha === '123456') {
      localStorage.setItem('logado', true);
      navigate('/');
    } else {
      setErro('Credenciais inválidas');
    }
  };

  return (
    <div className="container my-5">
      <div className="p-4 border rounded shadow-sm bg-white col-md-6 mx-auto">
        <h2 className="mb-4">Login Simples</h2>
        {erro && <div className="alert alert-danger">{erro}</div>}

        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label>Email:</label>
            <input type="email" name="email" className="form-control" value={form.email} onChange={handleChange} />
          </div>
          <div className="mb-3">
            <label>Senha:</label>
            <input type="password" name="senha" className="form-control" value={form.senha} onChange={handleChange} />
          </div>
          <button type="submit" className="btn btn-success w-100">Entrar</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
