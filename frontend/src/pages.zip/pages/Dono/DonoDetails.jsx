import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';

export default function DonoDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [dono, setDono] = useState(null);

  useEffect(() => {
    api.get(`/donos/${id}`)
      .then(response => setDono(response.data))
      .catch(error => console.error('Erro ao buscar dono:', error));
  }, [id]);

  const handleDelete = async () => {
    if (window.confirm('Tem certeza que deseja excluir este dono?')) {
      await api.delete(`/donos/${id}`);
      navigate('/donos');
    }
  };

  if (!dono) return <p>Carregando...</p>;

  return (
    <div className="container my-5">
      <div className="p-4 border rounded shadow-sm bg-white">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2>Detalhes do Dono</h2>
          <div>
            <Link to="/" className="btn btn-secondary me-2">← Voltar ao Início</Link>
            <Link to="/donos" className="btn btn-dark">Ver Donos</Link>
          </div>
        </div>

        <ul className="list-group mb-3">
          <li className="list-group-item"><strong>Nome:</strong> {dono.nome}</li>
          <li className="list-group-item"><strong>CPF:</strong> {dono.cpf}</li>
          <li className="list-group-item"><strong>Endereço:</strong> {dono.endereco}</li>
          <li className="list-group-item"><strong>Telefone:</strong> {dono.telefone}</li>
          <li className="list-group-item"><strong>Email:</strong> {dono.email}</li>
          <li className="list-group-item"><strong>Data de Nascimento:</strong> {dono.dataNascimento}</li>
          <li className="list-group-item"><strong>Responsável:</strong> {dono.responsavel ? 'Sim' : 'Não'}</li>
          <li className="list-group-item"><strong>Ativo:</strong> {dono.ativo ? 'Sim' : 'Não'}</li>
          <li className="list-group-item"><strong>Observações:</strong> {dono.observacoes}</li>
          <li className="list-group-item"><strong>Data de Cadastro:</strong> {dono.dataCadastro}</li>
        </ul>

        <button className="btn btn-warning me-2" onClick={() => navigate(`/donos/${id}/editar`)}>Editar</button>
        <button className="btn btn-danger" onClick={handleDelete}>Excluir</button>
      </div>
    </div>
  );
}