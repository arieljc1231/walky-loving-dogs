import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';

export default function PetDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [pet, setPet] = useState(null);
  const [eventos, setEventos] = useState([]);

  useEffect(() => {
    api.get(`/pets/${id}`).then(r => setPet(r.data)).catch(e => console.error('Erro ao buscar pet:', e));
    api.get(`/eventos/pet/${id}`).then(r => setEventos(r.data)).catch(e => console.error('Erro ao buscar eventos:', e));
  }, [id]);

  const handleDelete = async () => {
    if (window.confirm('Tem certeza que deseja excluir este pet?')) {
      await api.delete(`/pets/${id}`);
      navigate('/pets');
    }
  };

  const handleCheckout = async (eventoId) => {
    try {
      await api.put(`/eventos/${eventoId}/checkout`, {
        status: 'finalizado',
        dataSaida: new Date().toISOString()
      });
      const { data } = await api.get(`/eventos/pet/${id}`);
      setEventos(data);
    } catch (err) {
      console.error('Erro ao fazer check-out:', err);
    }
  };

  if (!pet) return <p>Carregando...</p>;

  return (
    <div className="container my-5">
      <div className="p-4 border rounded shadow-sm bg-white">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h3>Detalhes do Pet</h3>
          <div>
            <Link to="/" className="btn btn-secondary me-2">← Voltar ao Início</Link>
            <Link to="/pets" className="btn btn-dark">Ver Pets</Link>
          </div>
        </div>

        <ul className="list-group mb-3">
          <li className="list-group-item"><strong>Nome:</strong> {pet.nome}</li>
          <li className="list-group-item"><strong>Espécie:</strong> {pet.especie}</li>
          <li className="list-group-item"><strong>Raça:</strong> {pet.raca}</li>
          <li className="list-group-item"><strong>Idade:</strong> {pet.idade} anos</li>
          <li className="list-group-item"><strong>Peso:</strong> {pet.peso} kg</li>
          <li className="list-group-item"><strong>Porte:</strong> {pet.porte}</li>
          <li className="list-group-item"><strong>Sexo:</strong> {pet.sexo}</li>
          <li className="list-group-item"><strong>Cor:</strong> {pet.cor}</li>
          <li className="list-group-item"><strong>Castrado:</strong> {pet.castrado ? 'Sim' : 'Não'}</li>
          <li className="list-group-item"><strong>Carteira de Vacinação em Dia:</strong> {pet.carteiraVacinacao ? 'Sim' : 'Não'}</li>
          <li className="list-group-item"><strong>Data de Cadastro:</strong> {new Date(pet.dataCadastro).toLocaleDateString()}</li>
          <li className="list-group-item"><strong>Observações:</strong> {pet.observacoes || '—'}</li>
        </ul>

        <div className="d-flex justify-content-between">
          <div>
            <button className="btn btn-warning me-2" onClick={() => navigate(`/pets/${id}/editar`)}>Editar</button>
            <button className="btn btn-danger" onClick={handleDelete}>Excluir</button>
          </div>
          <Link to={`/pets/${id}/novo-evento`} className="btn btn-success">Cadastrar Evento</Link>
        </div>
      </div>

      <div className="mt-5 p-4 border rounded shadow-sm bg-white">
        <h5>Eventos relacionados</h5>
        {eventos.length === 0 ? (
          <p>Nenhum evento registrado.</p>
        ) : (
          <ul className="list-group">
            {eventos.map(ev => (
              <li key={ev._id} className="list-group-item d-flex justify-content-between align-items-center">
                <span>
                  <strong>{ev.tipo}</strong> - Check-in: {new Date(ev.dataEntrada).toLocaleDateString()} - Check-out: {ev.dataSaida ? new Date(ev.dataSaida).toLocaleDateString() : 'em andamento'}
                </span>
                {!ev.dataSaida && (
                  <button className="btn btn-outline-success btn-sm" onClick={() => handleCheckout(ev._id)}>
                    Fazer Check-out
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
