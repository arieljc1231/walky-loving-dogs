// src/pages/Evento/EditarEvento.jsx
import React from 'react';

const EditarEvento = () => {
  return (
    <div className="container mt-5">
      <h2>Editar Evento</h2>
      <p>Funcionalidade de edição de evento será implementada futuramente.</p>
    </div>
  );
};

export default EditarEvento;
